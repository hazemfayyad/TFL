﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace TFLRoadService
{
    public struct Road
    {
        public string name ;
        public string status ;
        public string statusDescription ;
    }

    internal class ServiceHelper
    {
        public static HttpWebResponse callService(string roadId)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            string appId = ConfigurationManager.AppSettings["AppId"];
            string appKey = ConfigurationManager.AppSettings["AppKey"];
            string serviceURL = ConfigurationManager.AppSettings["ServiceURL"];

            Uri address = new Uri(serviceURL + roadId + "?app_id=" + appId + "&app_key=" + appKey);

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(address);
            request.Method = "GET";
           
            return (HttpWebResponse)request.GetResponse();
        }

        public static Road parseJson(string strJson)
        {
            Road road = new Road();

            JavaScriptSerializer jss = new JavaScriptSerializer();
            Dictionary<string, object> dicRoad = (Dictionary<string, object>)((object[])jss.Deserialize<dynamic>(strJson))[0];

            road.name = dicRoad["displayName"].ToString();
            road.status = dicRoad["statusSeverity"].ToString();
            road.statusDescription = dicRoad["statusSeverityDescription"].ToString();

            return road;
        }

        public static string parseTextHTML(string strTxtHTML)
        {
            try
            {
                //find the tags containing the error information
                Regex h3Regex = new Regex("<h3.*?(?=</h3>)", RegexOptions.IgnoreCase);
                Regex pRegex = new Regex("<p.*?(?=</p>)", RegexOptions.Singleline);

                var result1 = h3Regex.Match(strTxtHTML.ToString()).Value;
                var result2 = pRegex.Match(strTxtHTML.ToString()).Value;

                //remove leading tags
                result1 = Regex.Replace(result1, "<.*?>", string.Empty);
                result2 = Regex.Replace(result2, "<.*?>", string.Empty);

                return result1 + ", " + result2;
            }catch (Exception exp)
            {
                return "An error occured while parsing response, please try again.";
            }
        }
    }
}