﻿using System;
using System.IO;
using System.Net;

namespace TFLRoadService
{
    public partial class RoadService : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            try
            {
                HttpWebResponse response = ServiceHelper.callService(tbRoad.Text);

                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                String responseStream = reader.ReadToEnd();

                reader.Close();
                dataStream.Close();

                if (response.ContentType.Contains("application/json"))
                {
                    divResult.Visible = true;
                    divError.Visible = false;

                    Road road = ServiceHelper.parseJson(responseStream);

                    lblName.Text = road.name;
                    lblStatus.Text = road.status;
                    lblDesc.Text = road.statusDescription;
                }
                else if (response.ContentType == "text/html")
                {
                    String error = ServiceHelper.parseTextHTML(responseStream);
                                        
                    divError.Visible = true;
                    divResult.Visible = false;

                    lblError.InnerText = error;
                }
            }
            catch (WebException webExp)
            {
                divError.Visible = true;
                divResult.Visible = false;

                if (webExp.Message.Contains("404"))
                {
                    lblError.InnerText = "Invalid Road Id, Please make sure you use a valid road ID";
                }
                else
                {
                    lblError.InnerText = "Sorry, an error occured while trying to connect to the road service. Error is:" + webExp.Message;
                }
            }
            catch (Exception exp)
            {
                divError.Visible = true;
                divResult.Visible = false;

                lblError.InnerText = "Sorry, an error occured while trying to connect to the road service. Error is:" + exp.Message;
            }
        }
    }
}