﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.IO;

namespace TFLRoadService.Tests
{    
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetRoadStatusValidRoad_ShouldReturnTrue()
        {
            Assert.AreEqual(callServiceTest("https://api.tfl.gov.uk/Road/", "fe5543c1", "929584e7a8354d0958e811f21fca0c74", "A2"), true);                    
        }

        [TestMethod]
        public void GetRoadStatusInValidRoad_ShouldReturnFalse()
        {
            Assert.AreEqual(callServiceTest("https://api.tfl.gov.uk/Road/", "fe5543c1", "929584e7a8354d0958e811f21fca0c74", "555"), false);
        }

        [TestMethod]
        public void GetRoadStatusInValidAppId_ShouldReturnFalse()
        {
            Assert.AreEqual(callServiceTest("https://api.tfl.gov.uk/Road/", "test", "929584e7a8354d0958e811f21fca0c74", "A2"), false);
        }

        [TestMethod]
        public void GetRoadStatusInValidAppKey_ShouldReturnFalse()
        {
            Assert.AreEqual(callServiceTest("https://api.tfl.gov.uk/Road/", "fe5543c1", "test", "A2"), false);
        }

        [TestMethod]
        public void GetRoadStatusInValidURL_ShouldReturnFalse()
        {
            Assert.AreEqual(callServiceTest("https://api.tfl.gov.uk/Roads/", "fe5543c1", "929584e7a8354d0958e811f21fca0c74", "A2"), false);
        }

        private bool callServiceTest(string URL, string appId, string appKey, string roadId)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            
            Uri address = new Uri(URL + roadId + "?app_id=" + appId + "&app_key=" + appKey);

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(address);
            request.Method = "GET";
            String responseStream = String.Empty;

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                responseStream = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();
                if (response.ContentType == "text/html")
                {
                    return false;
                }
                else
                    return true;

            }
            catch (WebException webExp)
            {
                return false;
            }
            catch (Exception exp)
            {
                return false;
            }
        } 
    }
}
